package com.phei.netty.ssl;

public enum SSLMODE {

    CA, CSA
}
